//  ViewController.swift
//  Calculator
//
//  Created by xcode on 28/02/17.
//  Copyright © 2017 xcode. All rights reserved.

import UIKit

class ViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBOutlet var result: UILabel!
   
    var current = 0


    @IBAction func bcero(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = (result.text! + "0")
    }
    @IBAction func buno(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = (result.text! + "1")
    }
    @IBAction func bdos(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = (result.text! + "2")
    }
    @IBAction func btres(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = (result.text! + "3")
    }
    @IBAction func bcuat(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = (result.text! + "4")
    }
    @IBAction func bcinco(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = (result.text! + "5")
    }
    @IBAction func bseis(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = (result.text! + "6")
    }
    @IBAction func bsiete(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = (result.text! + "7")
    }
    @IBAction func bocho(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = (result.text! + "8")
    }
    @IBAction func bnueve(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = (result.text! + "9")
    }
    
    
    @IBAction func igual(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = String(current)
    }
    @IBAction func punto(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = (result.text! + ".")
    }
    @IBAction func suma(_ sender: UIButton, forEvent event: UIEvent) {
        current = Int(result.text!)!
        result.text = "0"
        current = current + Int(result.text!)!
    }
    @IBAction func resta(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = "-"
    }
    @IBAction func mult(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = "*"
    }
    @IBAction func divi(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = "/"
    }
    @IBAction func porc(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = "%"
    }
    @IBAction func sign(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = "&"
    }
    @IBAction func clean(_ sender: UIButton, forEvent event: UIEvent) {
        result.text = "0"
    }
}

